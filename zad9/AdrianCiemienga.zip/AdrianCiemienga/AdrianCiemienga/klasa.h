#pragma once
#include <iostream>
using namespace std;

class Klasa
{
private:
	double a, b;

public:
	Klasa(double a, double b);

	double dzielenie();
	int modulo();
};
